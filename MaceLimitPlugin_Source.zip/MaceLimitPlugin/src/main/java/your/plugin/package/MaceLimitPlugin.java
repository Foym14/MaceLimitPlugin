
package your.plugin.package;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.*;
import org.bukkit.event.enchantment.PrepareItemEnchantEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Iterator;
import java.util.Map;

public class MaceLimitPlugin extends JavaPlugin implements Listener {

    private int maceCraftCount = 0;
    private static final int MAX_MACE_CRAFTS = 3;
    private NamespacedKey maceRecipeKey;

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        maceRecipeKey = new NamespacedKey(this, "mace");
        registerMaceRecipe();
    }

    private void registerMaceRecipe() {
        ItemStack mace = new ItemStack(Material.NETHERITE_AXE);
        ItemMeta meta = mace.getItemMeta();
        meta.setDisplayName("§6Mace");
        mace.setItemMeta(meta);

        ShapedRecipe maceRecipe = new ShapedRecipe(maceRecipeKey, mace);
        maceRecipe.shape(" I ", "ISI", " S ");
        maceRecipe.setIngredient('I', Material.IRON_BLOCK);
        maceRecipe.setIngredient('S', Material.STICK);

        Bukkit.addRecipe(maceRecipe);
    }

    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        if (event.getRecipe() == null || event.getRecipe().getResult() == null) return;

        ItemStack result = event.getRecipe().getResult();
        if (isMace(result)) {
            if (maceCraftCount >= MAX_MACE_CRAFTS) {
                event.getInventory().setResult(null);
            }
        }
    }

    @EventHandler
    public void onCraft(CraftItemEvent event) {
        if (event.getRecipe() == null || event.getRecipe().getResult() == null) return;

        ItemStack result = event.getRecipe().getResult();
        if (isMace(result)) {
            if (maceCraftCount < MAX_MACE_CRAFTS) {
                maceCraftCount++;
            } else {
                event.setCancelled(true);
                event.getWhoClicked().sendMessage("§cMace crafting limit reached.");
            }
        }
    }

    @EventHandler
    public void onAnvilPrepare(PrepareAnvilEvent event) {
        ItemStack result = event.getResult();
        if (result == null || !isMace(result)) return;

        if (hasIllegalEnchantments(result)) {
            event.setResult(null);
        }
    }

    @EventHandler
    public void onEnchant(PrepareItemEnchantEvent event) {
        ItemStack item = event.getItem();
        if (item == null || !isMace(item)) return;

        Iterator<Enchantment> it = event.getEnchantsToAdd().keySet().iterator();
        while (it.hasNext()) {
            Enchantment ench = it.next();
            if (!isAllowedEnchantment(ench)) {
                it.remove();
            }
        }
    }

    private boolean isMace(ItemStack item) {
        if (item.getType() != Material.NETHERITE_AXE) return false;
        if (!item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        return meta.hasDisplayName() && "§6Mace".equals(meta.getDisplayName());
    }

    private boolean isAllowedEnchantment(Enchantment ench) {
        return ench == Enchantment.MENDING || ench == Enchantment.DURABILITY;
    }

    private boolean hasIllegalEnchantments(ItemStack item) {
        for (Map.Entry<Enchantment, Integer> entry : item.getEnchantments().entrySet()) {
            if (!isAllowedEnchantment(entry.getKey())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onDisable() {
        Bukkit.removeRecipe(maceRecipeKey);
    }
}
